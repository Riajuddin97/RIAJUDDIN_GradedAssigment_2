package com.greatlearning.Stockers;

import java.util.Scanner;

public class StockersMain {
	public int choice = 1;
	public int noOfCompany;
	public boolean isIncrease[];
	public double stockPrice[];
	public double sortedStockPrice[];
	public double searchStocks;
	Scanner sc = new Scanner(System.in);

//Main function
	public static void main(String[] args) {

		StockersMain sd = new StockersMain();
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the no:of Companies");
		sd.noOfCompany = sc.nextInt();
		sd.stockPrice = new double[sd.noOfCompany];
		sd.isIncrease = new boolean[sd.noOfCompany];
		for (int i = 1; i <= sd.noOfCompany; i++) {
			System.out.println("Enter the current stock price for the Company " + i);
			sd.stockPrice[i - 1] = sc.nextDouble();
			System.out.println("Whether company's stock price rose today compare to yesterday?");
			sd.isIncrease[i - 1] = sc.nextBoolean();

		}
		sd.perform();
		sc.close();
	}

	public void perform() {
		// Merge function to sort the values
		MergeSort sort = new MergeSort();
		this.sortedStockPrice = sort.sort(this.stockPrice, 0, this.noOfCompany - 1);
		// statements for user inputs
		do {
			System.out.println("---------------------------------------------------------");
			System.out.println("Enter the option that you want to perform");
			System.out.println("1. Display the companies stock prices in ascending order");
			System.out.println("2. Display the companies stock prices in descending order");
			System.out.println("3. Display the total no of companies for which stock prices rose today");
			System.out.println("4. Display the total no of companies for which stock prices declined today");
			System.out.println("5. Search a specific stock price");
			System.out.println("6. press 0 for Exit");
			System.out.println("---------------------------------------------------------");
			this.choice = sc.nextInt();

			switch (this.choice) {
			case (1): {
				sortAscendingPrice();
				break;
			}
			case (2): {
				sortDecendingPrice();
				break;
			}
			case (3): {
				increasingstocks();
				break;
			}
			case (4): {
				decreasingstocks();
				break;
			}
			case (5): {
				searchstocks();
				break;
			}
			}

		} while (this.choice != 0);
		System.out.println("Exited Successfully");
	}

//function for ascending the values
	public void sortAscendingPrice() {
		System.out.println("Stock Prices in Ascending Order are : ");
		for (int i = 0; i < noOfCompany; i++) {
			System.out.println(sortedStockPrice[i]);
		}
	}

//function for descending the values
	public void sortDecendingPrice() {
		System.out.println("Stock Prices in Decending Order are : ");
		for (int i = this.noOfCompany - 1; i >= 0; i--) {
			System.out.println(sortedStockPrice[i]);

		}
	}

//function for check the no:of values increased 
	public void increasingstocks() {
		int count = 0;
		for (int i = 0; i < this.noOfCompany; i++) {
			if (this.isIncrease[i] == true) {
				count++;
			}
		}
		System.out.println("Total No:of Companies whose stock price rose today : " + count);
	}

	// function for check the no:of values decreased
	public void decreasingstocks() {
		int count = 0;
		for (int i = 0; i < this.noOfCompany; i++) {
			if (this.isIncrease[i] == false) {
				count++;
			}
		}
		System.out.println("Total No:of Companies whose stock price declined today : " + count);
	}

//function for check the given value present/not
	public void searchstocks() {
		BinarySearch search = new BinarySearch();
		System.out.println("Enter the Key Value : ");
		this.searchStocks = sc.nextDouble();
		search.searchValue(searchStocks, sortedStockPrice);

	}
}