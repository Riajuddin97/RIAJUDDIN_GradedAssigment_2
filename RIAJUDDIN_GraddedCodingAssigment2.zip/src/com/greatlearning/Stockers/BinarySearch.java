package com.greatlearning.Stockers;

public class BinarySearch {

	public void searchValue(double searchstocks, double[] allStocks) {
		int l, r, mid;
		l = 0;
		r = allStocks.length - 1;
		mid = l + (r - l) / 2;
		while (l <= r) {
			if (searchstocks < allStocks[mid]) {// range is l to mid-1
				r = mid - 1;
			} else if (searchstocks > allStocks[mid]) {// range is mid+1 to r
				l = mid + 1;
			} else {
				System.out.println("stock of value " + searchstocks + " is present");
				break;
			}
			mid = l + (r - l) / 2;
		}
		if (l > r) {
			System.out.println("stock of value " + searchstocks + " is not present");
		}
	}
}